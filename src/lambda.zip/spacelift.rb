# frozen_string_literal: true

def lambda_handler(event:, context:)
  puts "hello world"
end
